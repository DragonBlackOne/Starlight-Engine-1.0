#version 410 core
layout (location = 0) out vec4 outColor;
in vec2 v_uv;

uniform sampler2D scene;
uniform float threshold;

void main() {
    vec3 color = texture(scene, v_uv).rgb;
    float brightness = dot(color, vec3(0.2126, 0.7152, 0.0722));
    if(brightness > threshold)
        outColor = vec4(color, 1.0);
    else
        outColor = vec4(0.0, 0.0, 0.0, 1.0);
}
