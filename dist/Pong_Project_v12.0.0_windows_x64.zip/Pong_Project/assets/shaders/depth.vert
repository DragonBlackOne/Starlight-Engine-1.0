#version 330 core
in vec3 in_position;
uniform mat4 u_light_space_matrix;
uniform mat4 u_model;
void main() {
    gl_Position = u_light_space_matrix * u_model * vec4(in_position, 1.0);
}
