@echo off
REM ==============================================================================
REM Automated SteamPipe Deployment Script for Starlight Engine 3D Tech Demo
REM Requires steamcmd in PATH or specify location
REM ==============================================================================
echo [SteamPipe] Preparing upload for AppID 480...
steamcmd +login <your_steam_account> +run_app_build "%~dp0app_build_480.vdf" +quit
pause
